# cryptowatch-chrome-extension
A Google Chrome browser extension that allows you to alter the CSS of cryptowat.ch
