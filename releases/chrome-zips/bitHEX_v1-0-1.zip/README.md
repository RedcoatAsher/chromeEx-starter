# bitHEX
A Google Chrome browser extension that alters the CSS of cryptowat.ch for easier readability.
